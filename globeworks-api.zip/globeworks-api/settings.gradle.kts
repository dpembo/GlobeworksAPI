rootProject.name = "globeworks-api"
